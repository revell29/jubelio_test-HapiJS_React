import { startServer } from "./server";

// run server
startServer();
